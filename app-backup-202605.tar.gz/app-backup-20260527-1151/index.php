<?php require_once 'config.php'; ?>
<?php require_once 'includes/header.php'; ?>
<?php require_once 'includes/nav.php'; ?>

<h2>Dashboard</h2>
<p>Welcome to the Hope Baptist Church Treasurer System.</p>

<?php require_once 'includes/footer.php'; ?>
