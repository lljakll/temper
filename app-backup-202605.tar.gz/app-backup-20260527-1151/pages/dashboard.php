<?php
// Dashboard page following Treasurer's Guide principles
// Based on Conceptual Edition Rev 1.0 - Stewardship & GAAP Compliance

// Include necessary files
require_once '../config.php';
require_once '../includes/header.php';
require_once '../includes/nav.php';
?>

<!-- Dashboard Header -->
<div class="row mb-4">
    <div class="col-12">
        <h2 class="mb-0">Financial Dashboard</h2>
        <p class="text-muted">Stewardship & Accountability Dashboard | Based on Treasurer's Guide, Rev 1.0</p>
    </div>
</div>

<!-- Fund Status Cards -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card border-primary">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="bi bi-wallet"></i> Net Assets Without Donor Restrictions (WODR)</h5>
            </div>
            <div class="card-body">
                <h3 class="text-primary">$0.00</h3>
                <p class="card-text">Unrestricted operating resources for any legitimate ministry or operational purpose.</p>
                <small class="text-muted">Current balance</small>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-success">
            <div class="card-header bg-success text-white">
                <h5 class="mb-0"><i class="bi bi-wallet2"></i> Net Assets With Donor Restrictions (WDR)</h5>
            </div>
            <div class="card-body">
                <h3 class="text-success">$0.00</h3>
                <p class="card-text">Resources used only for specific donor-designated purposes.</p>
                <small class="text-muted">Current balance</small>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activity -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0"><i class="bi bi-clock-history"></i> Recent Activity</h5>
            </div>
            <div class="card-body">
                <p class="card-text">Recent financial transactions and activities will appear here.</p>
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1">No recent activity</h6>
                            <small class="text-muted">Today</small>
                        </div>
                        <p class="mb-1">The system is ready for data entry.</p>
                    </a>
                    <a href="#" class="list-group-item list-group-item-action">
                        <div class="d-flex w-100 justify-content-between">
                            <h6 class="mb-1">System initialized</h6>
                            <small class="text-muted">2026-05-27</small>
                        </div>
                        <p class="mb-1">Treasurer system prepared per Rev 1.0 guidelines.</p>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Include footer
require_once '../includes/footer.php';
?>
