<?php
require_once 'config.php';
require_once 'auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    // Redirect to login page
    header('Location: login.php');
    exit;
}

// Get current user
$user = getCurrentUser();
?>

<?php require_once 'includes/header.php'; ?>
<?php require_once 'includes/nav.php'; ?>

<h2>Dashboard</h2>
<p>Welcome, <?php echo htmlspecialchars($user['name']); ?>!</p>
<p>You are logged in to the Hope Baptist Church Treasurer System.</p>

<?php require_once 'includes/footer.php'; ?>
