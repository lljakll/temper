<?php
// setup.php
// Basic setup page with Bootstrap tabs
//require_once '../include/header.php';
//require_once 'nav.php';
?>

<div class="container mt-5">
    <h1 class="mb-4">System Setup</h1>
    
    <!-- Nav tabs -->
    <ul class="nav nav-tabs" id="setupTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="funds-tab" data-bs-toggle="tab" data-bs-target="#funds" type="button" role="tab">Funds</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="accounts-tab" data-bs-toggle="tab" data-bs-target="#accounts" type="button" role="tab">Accounts</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="natural-classes-tab" data-bs-toggle="tab" data-bs-target="#natural-classes" type="button" role="tab">Natural Classes</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="functional-classes-tab" data-bs-toggle="tab" data-bs-target="#functional-classes" type="button" role="tab">Functional Classes</button>
        </li>
    </ul>
    
    <!-- Tab panes -->
    <div class="tab-content" id="setupTabContent">
        <div class="tab-pane fade show active" id="funds" role="tabpanel">
            <div class="p-3">
                <?php include 'setup_funds.php'; ?>
            </div>
        </div>
        <div class="tab-pane fade" id="accounts" role="tabpanel">
            <div class="p-3">
                <p>Setup for Accounts coming soon.</p>
            </div>
        </div>
        <div class="tab-pane fade" id="natural-classes" role="tabpanel">
            <div class="p-3">
                <p>Setup for Natural Classes coming soon.</p>
            </div>
        </div>
        <div class="tab-pane fade" id="functional-classes" role="tabpanel">
            <div class="p-3">
                <p>Setup for Functional Classes coming soon.</p>
            </div>
        </div>
    </div>
</div>

<?php
//require_once 'footer.php';
?>

