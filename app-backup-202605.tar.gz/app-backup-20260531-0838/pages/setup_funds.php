<?php
// Load database connection
require_once __dir__ . '/../config.php';
$db = getDbConnection();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];
        
        if ($action === 'add') {
            // Insert new fund record
            $name = $_POST['name'] ?? '';
            $code = $_POST['code'] ?? '';
            $type = $_POST['type'] ?? '';
            $description = $_POST['description'] ?? '';
            $archived = isset($_POST['archived']) ? 1 : 0;
            
            $stmt = $db->prepare("INSERT INTO funds (name, code, type, description, archived) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $name, $code, $type, $description, $archived);
            $stmt->execute();
            $stmt->close();
        }
        elseif ($action === 'edit') {
            // Update existing fund record
            $id = $_POST['id'] ?? 0;
            $name = $_POST['name'] ?? '';
            $code = $_POST['code'] ?? '';
            $type = $_POST['type'] ?? '';
            $description = $_POST['description'] ?? '';
            $archived = isset($_POST['archived']) ? 1 : 0;
            
            $stmt = $db->prepare("UPDATE funds SET name=?, code=?, type=?, description=?, archived=? WHERE id=?");
            $stmt->bind_param("sssssi", $name, $code, $type, $description, $archived, $id);
            $stmt->execute();
            $stmt->close();
        }
        elseif ($action === 'delete') {
            // Delete fund record
            $id = $_POST['id'] ?? 0;
            $stmt = $db->prepare("DELETE FROM funds WHERE id=?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $stmt->close();
        }
        elseif ($action === 'archive') {
            // Archive/unarchive fund record
            $id = $_POST['id'] ?? 0;
            $archived = $_POST['archived'] ?? 0;
            
            $stmt = $db->prepare("UPDATE funds SET archived=? WHERE id=?");
            $stmt->bind_param("ii", $archived, $id);
            $stmt->execute();
            $stmt->close();
        }
    }
}

// Check if 'show_archived' parameter is set
$show_archived = isset($_GET['show_archived']) && $_GET['show_archived'] == '1';

// Build query for funds
if ($show_archived) {
    $funds_query = "SELECT id, name, code, type, description, archived FROM funds ORDER BY name";
} else {
    $funds_query = "SELECT id, name, code, type, description, archived FROM funds WHERE archived = FALSE ORDER BY name";
}

$funds_result = $db->query($funds_query);
?>

<div class="container mt-4">
    <h2 class="mb-4">Funds Setup</h2>
    
    <!-- Controls -->
    <div class="row mb-3">
        <div class="col-md-6">
            <a href="?show_archived=<?= $show_archived ? '0' : '1' ?>" class="btn btn-outline-secondary">
                <?= $show_archived ? 'Hide' : 'Show' ?> Archived
            </a>
        </div>
        <div class="col-md-6 text-end">
            <button id="addBtn" class="btn btn-primary me-2">Add</button>
            <button id="editBtn" class="btn btn-secondary me-2" disabled>Edit</button>
            <button id="deleteBtn" class="btn btn-danger me-2" disabled>Delete</button>
            <button id="archiveBtn" class="btn btn-warning me-2" disabled>Archive/Unarchive</button>
        </div>
    </div>
    
    <!-- Fund Table -->
    <div class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Type</th>
                    <th>Description</th>
                    <th>Archived</th>
                </tr>
            </thead>
            <tbody id="fundsTableBody">
                <?php if ($funds_result && $funds_result->num_rows > 0): ?>
                    <?php while ($fund = $funds_result->fetch_assoc()): ?>
                        <tr data-id="<?= $fund['id'] ?>">
                            <td><?= htmlspecialchars($fund['name']) ?></td>
                            <td><?= htmlspecialchars($fund['code'] ?? '') ?></td>
                            <td><?= htmlspecialchars($fund['type']) ?></td>
                            <td><?= htmlspecialchars($fund['description'] ?? '') ?></td>
                            <td><?= $fund['archived'] ? 'Yes' : 'No' ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5" class="text-center">No funds found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <!-- Form for adding/editing -->
    <div id="fundForm" class="mt-4 d-none">
        <h4 id="formTitle">Add New Fund</h4>
        <form id="fundFormContent" method="POST">
            <input type="hidden" id="fundId" name="id">
            <input type="hidden" name="action" id="formAction">
            
            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            
            <div class="mb-3">
                <label for="code" class="form-label">Code</label>
                <input type="text" class="form-control" id="code" name="code">
            </div>
            
            <div class="mb-3">
                <label for="type" class="form-label">Type</label>
                <select class="form-select" id="type" name="type" required>
                    <option value="WODR">WODR - Without Donor Restrictions</option>
                    <option value="WDR">WDR - With Donor Restrictions</option>
                </select>
            </div>
            
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
            </div>
            
            <div class="mb-3 form-check">
                <input type="checkbox" class="form-check-input" id="archived" name="archived">
                <label class="form-check-label" for="archived">Archived</label>
            </div>
            
            <button type="submit" class="btn btn-primary">Save</button>
            <button type="button" class="btn btn-secondary" id="cancelBtn">Cancel</button>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const tableBody = document.getElementById('fundsTableBody');
    const addBtn = document.getElementById('addBtn');
    const editBtn = document.getElementById('editBtn');
    const deleteBtn = document.getElementById('deleteBtn');
    const archiveBtn = document.getElementById('archiveBtn');
    const fundForm = document.getElementById('fundForm');
    const fundFormContent = document.getElementById('fundFormContent');
    const formAction = document.getElementById('formAction');
    const fundId = document.getElementById('fundId');
    const formTitle = document.getElementById('formTitle');
    const cancelBtn = document.getElementById('cancelBtn');
    
    let selectedRow = null;
    
    // Enable/disable buttons based on row selection
    tableBody.addEventListener('click', function(event) {
        const row = event.target.closest('tr');
        if (row) {
            // Deselect previous row
            if (selectedRow) {
                selectedRow.classList.remove('table-info');
            }
            
            // Select new row
            selectedRow = row;
            if (selectedRow) {
                selectedRow.classList.add('table-info');
                // Enable action buttons
                editBtn.disabled = false;
                deleteBtn.disabled = false;
                archiveBtn.disabled = false;
            }
        }
    });
    
    // Add button
    addBtn.addEventListener('click', function() {
        // Reset form
        fundFormContent.reset();
        formAction.value = 'add';
        formTitle.textContent = 'Add New Fund';
        fundId.value = '';
        fundForm.classList.remove('d-none');
        
        // Disable action buttons during editing
        addBtn.disabled = true;
        editBtn.disabled = true;
        deleteBtn.disabled = true;
        archiveBtn.disabled = true;
    });
    
    // Edit button
    editBtn.addEventListener('click', function() {
        if (!selectedRow) return;
        
        // Get fund data from the row
        const id = selectedRow.getAttribute('data-id');
        const name = selectedRow.cells[0].textContent;
        const code = selectedRow.cells[1].textContent;
        const type = selectedRow.cells[2].textContent;
        const description = selectedRow.cells[3].textContent;
        const archived = selectedRow.cells[4].textContent === 'Yes';
        
        // Fill form
        fundId.value = id;
        document.getElementById('name').value = name;
        document.getElementById('code').value = code;
        document.getElementById('type').value = type;
        document.getElementById('description').value = description;
        document.getElementById('archived').checked = archived;
        
        formAction.value = 'edit';
        formTitle.textContent = 'Edit Fund';
        fundForm.classList.remove('d-none');
        
        // Disable action buttons during editing
        addBtn.disabled = true;
        editBtn.disabled = true;
        deleteBtn.disabled = true;
        archiveBtn.disabled = true;
    });
    
    // Delete button
    deleteBtn.addEventListener('click', function() {
        if (!selectedRow) return;
        
        const id = selectedRow.getAttribute('data-id');
        if (confirm('Are you sure you want to delete this fund?')) {
            // Set action to delete
            formAction.value = 'delete';
            fundId.value = id;
            
            // Submit form
            fundFormContent.submit();
        }
    });
    
    /*/ Archive/Unarchive button
    archiveBtn.addEventListener('click', function() {
        if (!selectedRow) return;
        
        const id = selectedRow.getAttribute('data-id');
        const isArchived = selectedRow.cells[4].textContent === 'Yes';
        
        // Set action to archive
        formAction.value = 'archive';
        fundId.value = id;
        document.getElementById('archived').checked = !isArchived;
        
        // Submit form
        fundFormContent.submit();
    });*/

    // Archive/Unarchive button
    archiveBtn.addEventListener('click', function() {
        if (!selectedRow) {
            alert("Please select a fund first.");
            return;
        }
        
        const id = selectedRow.getAttribute('data-id');
        const isCurrentlyArchived = selectedRow.cells[4].textContent.trim() === 'Yes';
        const newArchivedState = !isCurrentlyArchived;
        
        if (confirm(`Are you sure you want to ${newArchivedState ? 'archive' : 'unarchive'} this fund?`)) {
            // Set form values for archive action
            formAction.value = 'archive';
            fundId.value = id;
            document.getElementById('archived').checked = newArchivedState;
            
            // Submit the form
            fundFormContent.submit();
        }
    });
    
    // Cancel button
    cancelBtn.addEventListener('click', function() {
        fundForm.classList.add('d-none');
        
        // Re-enable action buttons
        addBtn.disabled = false;
        editBtn.disabled = true;
        deleteBtn.disabled = true;
        archiveBtn.disabled = true;
    });
    
    // Handle form submission
    fundFormContent.addEventListener('submit', function(e) {
        // Submit form
        fundFormContent.submit();
    });
});
</script>