<?php
require_once 'config.php';
require_once 'auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    // Redirect to login page
    header('Location: login.php');
    exit;
}

// Get the page, default to dashboard
$page = $_GET['page'] ?? 'dashboard';

// Get current user
$user = getCurrentUser();

require_once 'includes/header.php';
require_once 'includes/nav.php';

?>


<div class="col-md-10 p-4">
    <?php
    switch ($page) {
        case 'setup':
            require_once 'pages/setup.php';
            break;
        case 'ledger':           // formerly transactions
            require_once 'pages/ledger.php';
            break;
        case 'reports':
            require_once 'pages/reports.php';
            break;
        case 'funds':
            require_once 'pages/funds.php';
            break;
        default:
            require_once 'pages/dashboard.php';
    }
    ?>
</div>

<?php require_once 'includes/footer.php'; ?>
