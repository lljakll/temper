<div class="row">
    <div class="col-md-2 bg-dark text-white min-vh-100 p-3">

        <ul class="nav flex-column">
            <li class="nav-item">
                <a href="?page=dashboard" class="nav-link text-white">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
            </li>
            <li class="nav-item">
                <a href="?page=../pages/dashboard.php" class="nav-link text-white">
                    <i class="bi bi-currency-dollar"></i> Ledger
                </a>
            </li>
            <li class="nav-item">
                <a href="?page=../pages/dashboard.php" class="nav-link text-white">
                    <i class="bi bi-wallet2"></i> Funds
                </a>
            </li>
            <li class="nav-item">
                <a href="?page=../pages/dashboard.php" class="nav-link text-white">
                    <i class="bi bi-file-earmark-bar-graph"></i> Reports
                </a>
            </li>
            <li class="nav-item">
                <a href="?page=../pages/dashboard.php" class="nav-link text-white">
                    <i class="bi bi-graph-up"></i> Budget
                </a>
            </li>
            <li class="nav-item">
                <a href="?page=setup" class="nav-link text-white">
                    <i class="bi bi-gear"></i> Setup
                </a>
            </li>
        </ul>
        <hr class="bg-white">
        <small class="text-muted">Based on Treasurer's Guide, Rev 1.0</small>
    </div>
    <div class="col-md-10 p-4">
