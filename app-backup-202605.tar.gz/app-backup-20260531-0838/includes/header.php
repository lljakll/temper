<?php
if (!isset($user) && function_exists('getCurrentUser')) {
    $user = getCurrentUser();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?? "Hope Baptist Treasurer" ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
</head>
<body class="bg-light">

<!-- Simple Top Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark shadow-sm mb-4">
    <div class="container-fluid px-4">
        <!-- Logo / Brand -->
        <a class="navbar-brand d-flex align-items-center" href="index.php">
            <i class="bi bi-bank me-2"></i>
            Hope Baptist Treasurer
        </a>

        <!-- User Info & Logout -->
        <div class="d-flex align-items-center gap-3">
            <span class="text-light">
                Welcome, <strong><?= htmlspecialchars($user['name'] ?? 'Admin') ?></strong>
            </span>
            <a href="logout.php" class="btn btn-outline-light btn-sm">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>
</nav>

<div class="container-fluid px-4">